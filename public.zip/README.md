# Static Web App Project

This project demoes serving static files with Nodejs and Express.

### Usage

Make sure to run in project root:

```
$ npm intall
```

Then start the project:

```
$ npm run dev
```

This will watch the project directory and restart as necessary.

## Special Attributions for this project

- [donsky](https://github.com/donskytech/sample-static-node-express-web-application.git)